<?php
    session_start();
    session_destroy();
    header('Location: CISC3003-FinalExamP3-dc326264-index.php');
?>