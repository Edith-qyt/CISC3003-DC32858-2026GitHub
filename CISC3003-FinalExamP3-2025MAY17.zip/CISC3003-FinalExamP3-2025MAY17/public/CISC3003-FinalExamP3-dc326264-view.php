<?php session_start(); 
require_once('./include/pdo.php');
?>
<!DOCTYPE html>
<html>
    <head>
        <title>CISC3003 FinalExamP03 - dc326264 Cheang Ngou Hin</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

    </head>
    <body class="vsc-initialized">
        <?php if (!isset($_SESSION['name'])) die('Not logged in'); ?>
        <div class="container">
            <h1>Tracking Autos for <?= $_SESSION['name']; ?></h1>
            <h2>Automobiles</h2>
            <ul>
                <?php 
                    $autos_items = $pdo->query("SELECT * FROM `autos`");
                    while ($row = $autos_items->fetch(PDO::FETCH_ASSOC)) {
                        echo "<li>".htmlentities($row['year'])." ".htmlentities($row['make'])." / ".htmlentities($row['mileage'])."</li>";
                    }
                ?>
            </ul>
            <p>
                <a href="./CISC3003-FinalExamP3-dc326264-add.php">Add New</a> |
                <a href="./CISC3003-FinalExamP3-dc326264-logout.php">Logout</a>
            </p>
        </div>
    </body>
</html>