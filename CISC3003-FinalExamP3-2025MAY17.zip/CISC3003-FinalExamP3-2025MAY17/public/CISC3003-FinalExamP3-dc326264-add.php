<?php session_start(); 
require_once('./include/pdo.php');

if (isset($_POST['add'])) {
    // 验证输入
    if (empty($_POST['make']) || empty($_POST['year']) || empty($_POST['mileage'])) {
        $_SESSION['error'] = "All fields are required";
    } elseif (!is_numeric($_POST['year']) || !is_numeric($_POST['mileage'])) {
        $_SESSION['error'] = "Year and Mileage must be numeric";
    } else {
        // 插入数据到数据库
        $stmt = $pdo->prepare('INSERT INTO autos (brand, year, price) VALUES (:mk, :yr, :mi)');
        $stmt->execute(array(
            ':mk' => $_POST['make'],
            ':yr' => $_POST['year'],
            ':mi' => $_POST['mileage']
        ));
        $_SESSION['success'] = "Record added";
        header("Location: CISC3003-FinalExamP3-dc326264-view.php");
        return;
    }
    header("Location: CISC3003-FinalExamP3-dc326264-add.php");
    return;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>CISC3003 FinalExamP03 - dc326264 Cheang Ngou Hin</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

    </head>
    <body class="vsc-initialized">
        <?php if (!isset($_SESSION['name'])) die('Not logged in'); ?>
        <div class="container">
            <h1>Tracking Autos for <?= htmlentities($_SESSION['name']); ?></h1>
            
            <?php
                if (isset($_SESSION['error'])) {
                    echo('<p style="color: red;">'.htmlentities($_SESSION['error'])."</p>\n");
                    unset($_SESSION['error']);
                }
                if (isset($_SESSION['success'])) {
                    echo('<p style="color: green;">'.htmlentities($_SESSION['success'])."</p>\n");
                    unset($_SESSION['success']);
                }
            ?>

            <form method="POST">
                <p>Make: <input type="text" name="make" size="40"></p>
                <p>Year: <input type="text" name="year"></p>
                <p>Mileage: <input type="text" name="mileage"></p>
                <input type="submit" name="add" value="Add">
                <input type="submit" name="cancel" value="Cancel">
            </form>
        </div>
    </body>
</html>