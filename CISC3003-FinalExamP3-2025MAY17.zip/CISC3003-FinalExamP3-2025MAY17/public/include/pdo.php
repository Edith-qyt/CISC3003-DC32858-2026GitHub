<?php
    $host = 'localhost';
    $dbname = 'shop_db';
    $dbusername = 'root';
    $dbpassword = '';
    $pdo = new PDO("mysql:host=$host;port=3307;dbname=$dbname", $dbusername, $dbpassword);
    //$pdo = new PDO('mysql:host=127.0.2.2:3306;dbname=shop_db', 'ruser', 'Pa$$w0rd');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>