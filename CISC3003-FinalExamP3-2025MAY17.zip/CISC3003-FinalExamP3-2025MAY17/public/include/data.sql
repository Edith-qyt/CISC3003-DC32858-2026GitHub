USE car_db;

CREATE TABLE autos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    make VARCHAR(50) NOT NULL,
    year INT,
    mileage INT
);

INSERT INTO autos (year, make, mileage) VALUES
(2014, "Mini Cooper", 12345),
(1978, "Subaru Brat", 304050);