<!DOCTYPE html>
<html>
    <head>
    <title>CISC3003 FinalExamP03 - dc326264 Cheang Ngou Hin</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

</head>
    <body class="vsc-initialized">
        <div class="container">
            <h1>Welcome to CISC3003 Autos Database</h1>
            <p>
                <a href="./CISC3003-FinalExamP3-dc326264-login.php">Please Log In</a>
            </p>
            <p>
                Attempt to go to 
                <a href="./CISC3003-FinalExamP3-dc326264-view.php">view.php</a> without logging in - it should fail with an error message.
            </p>
            <p>
                Attempt to go to 
                <a href="./CISC3003-FinalExamP3-dc326264-add.php">add.php</a> without logging in - it should fail with an error message.
            </p>
            <p>
                <a href="https://www.wa4e.com/assn/autosess/" target="_blank">Specification for this Application</a>
            </p>
        </div>
    </body>
</html>