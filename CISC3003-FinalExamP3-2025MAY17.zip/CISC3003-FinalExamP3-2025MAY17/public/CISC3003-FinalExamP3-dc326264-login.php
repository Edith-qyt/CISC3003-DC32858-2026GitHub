<?php
if(isset($_POST["cancel"])) {
    unset($_POST["email"]);
    unset($_POST["pass"]);
    unset($_POST["cancel"]);
    header("Location: CISC3003-FinalExamP3-dc326264-index.php");
    exit;
}
elseif(isset($_POST["email"])) {
    if(empty($_POST["email"]) || empty($_POST["pass"])) {
        $error = "<p style=\"color: red;\">Email and password are required</p>";
    }
    elseif(!str_contains($_POST["email"], "@")) {
        $error = "<p style=\"color: red;\">Email must have an at-sign (@)</p>";
    }
    elseif($_POST["pass"] != "php123") {
        error_log("Login fail ".$_POST["email"]." ".hash("sha256", $_POST["pass"])."");
        $error = "<p style=\"color: red;\">Incorrect password</p>";
    }
    else{
        error_log("Login success ".$_POST['email']);
        session_start();
        $_SESSION['name'] = htmlentities($_POST['email']);
        header("Location: CISC3003-FinalExamP3-dc326264-view.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>CISC3003 FinalExamP03 - dc326264 Cheang Ngou Hin</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">

    </head>
    <body class="vsc-initialized">
        <div class="container">
            <h1>Please Log In</h1>
            <?php
                if(isset($_POST["cancel"])) {
                    unset($_POST["email"]);
                    unset($_POST["pass"]);
                    unset($_POST["cancel"]);
                    header("Location: CISC3003-FinalExamP3-dc326264-index.php");
                }
                elseif(isset($_POST["email"])) {
                    if(empty($_POST["email"]) || empty($_POST["pass"])) {
                        echo "<p style=\"color: red;\">Email and password are required</p>";
                    }
                    elseif(!str_contains($_POST["email"], "@")) {
                        echo "<p style=\"color: red;\">Email must have an at-sign (@)</p>";
                    }
                    elseif($_POST["pass"] != "php123") {
                        error_log("Login fail ".$_POST["email"]." ".hash("sha256", $_POST["pass"])."");
                        echo "<p style=\"color: red;\">Incorrect password</p>";
                    }
                    else{
                        error_log("Login success ".$_POST['email']);
                        session_start();
                        $_SESSION['name'] = htmlentities($_POST['email']);
                        header("Location: CISC3003-FinalExamP3-dc326264-view.php");
                    }
                }
            ?>
            <form method="POST" action="./CISC3003-FinalExamP3-dc326264-login.php">
                <label for="email">Email</label>
                <input type="text" name="email" id="email"><br>
                <label for="id_1723">Password</label>
                <input type="text" name="pass" id="id_1723"><br>
                <input type="submit" value="Log In">
                <input type="submit" name="cancel" value="Cancel">
            </form>
            <p>
                For a password hint, view source and find an account and password hint
                in the HTML comments.
                <!-- Hint:
                The account is csev@umich.edu
                The password is the three character name of the
                programming language used in this class (all lower case)
                followed by 123. -->
            </p>
        </div>

    </body>
</html>